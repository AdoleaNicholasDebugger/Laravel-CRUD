
    <?php $__env->startSection('content'); ?>
        i am the projects page
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\LaravelCRUD\resources\views/pages/projects.blade.php ENDPATH**/ ?>