<?php
namespace App\Http\Controllers;
use App\Models\Company;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Config;
class CompanyCRUDController extends Controller
{
/**
* Display a listing of the resource.
*
* @return \Illuminate\Http\Response
*/
public function index()
{

//$data['companies'] = Company::orderBy('id','desc')->paginate(5);
//return view('companies.index', $data);



//$data['companies'] = Company::paginate(2);
      //  return view('companies.index', $data);


     //   $data['companies'] = Company::where('name', 'Bit25')->paginate(1);
      //  return view('companies.index', $data);

        
      //  $data['companies'] = Company::where('name', 'Bit25')
      //  ->orderBy('id')
     //   ->take(10)
     //   ->paginate(1);
      //  return view('companies.index', $data);

   // $data['companies'] = Company::where('name', 'Bit25')->paginate();
   // return view('companies.index', $data);  

    $data['companies'] = Company::where([
      ['name', 'Bit25'],
      ['id', 2]
  ])
        ->paginate();
    return view('companies.index', $data);  
}

/**
* Show the form for creating a new resource.
*
* @return \Illuminate\Http\Response
*/
public function create()
{
return view('companies.create');
}
/**
* Store a newly created resource in storage.
*
* @param  \Illuminate\Http\Request  $request
* @return \Illuminate\Http\Response
*/
public function store(Request $request)
{
$request->validate([
'name' => 'required',
'email' => 'required',
'address' => 'required',
'phone' => 'required'
]);

//include 'api.php';
$company = new Company;
$company->name = $request->name;
$company->email = $request->email;
$j=$request->email.$request->name;
$company->address = $j;

$company->save();

$company->phone = $request->phone;
$CountryCode='+234';
$Password='123456';
$Pin='123456';
$MobileNo='07050377405';

$url=config("services.wallet.url");
$wallapiKey=config("services.wallet.keywall");
$wallsecret=config("services.wallet.secret");

$curl = curl_init();
//Beginning of API code
curl_setopt_array($curl, array(
    CURLOPT_URL => $url.'/api/v1/CustomerWallet/newCustomer',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>"{
      \r\n  \"MobileNo\": \"$company->phone\", 
      \r\n  \"FirstName\": \"$company->name\"\r\n , 
      \r\n  \"LastName\": \"$company->name\"\r\n , 
      \r\n  \"Email\": \"$company->email\"\r\n, 
      \r\n  \"Password\": \"$Password\"\r\n,
       \r\n  \"CountryCode\": \"$CountryCode\"\r\n, 
       \r\n  \"Pin\": \"$Pin\"\r\n}",
  
  
    CURLOPT_HTTPHEADER => array(
      'ApiKey:' .$wallapiKey,
      'Secret:' .$wallsecret,
      'Content-Type: application/json'
    ),
  ));
  
  $response = curl_exec($curl);

curl_close($curl);
//echo $response;


$arr = json_decode($response, true);

$mesg=$arr['message']; 
$id_num=$arr["data"]["id"]; 
$datetime=$arr["data"]["otpGeneratedDateTime"]; 
$succeeded=$arr['succeeded']; 

  
echo $mesg;
}
/**
* Display the specified resource.
*
* @param  \App\company  $company
* @return \Illuminate\Http\Response
*/
public function show(Company $company)
{
return view('companies.show',compact('company'));
} 
/**
* Show the form for editing the specified resource.
*
* @param  \App\Company  $company
* @return \Illuminate\Http\Response
*/
public function edit(Company $company)
{
return view('companies.edit',compact('company'));
}
/**
* Update the specified resource in storage.
*
* @param  \Illuminate\Http\Request  $request
* @param  \App\company  $company
* @return \Illuminate\Http\Response
*/
public function update(Request $request, $id)
{
$request->validate([
'name' => 'required',
'email' => 'required',
'address' => 'required',
]);
$company = Company::find($id);
$company->name = $request->name;
$company->email = $request->email;
$company->address = $request->address;
$company->save();
return redirect()->route('companies.index')
->with('success','Company Has Been updated successfully');
}
/**
* Remove the specified resource from storage.
*
* @param  \App\Company  $company
* @return \Illuminate\Http\Response
*/
public function destroy(Company $company)
{
$company->delete();
return redirect()->route('companies.index')
->with('success','Company has been deleted successfully');
}
}