

    <?php $__env->startSection('content'); ?>
        i am the about page
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\LaravelCRUD\resources\views/pages/about.blade.php ENDPATH**/ ?>